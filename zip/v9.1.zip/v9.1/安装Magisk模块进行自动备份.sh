MODDIR="${0%/*}"
test "$(id -u)" -ne 0 && echo "你是憨批？不给Root用你妈 爬" && exit 1
Magisk=true
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $MODDIR/tools ]] && echo "$MODDIR/tools目录遗失" && exit 1
[[ ! -d $MODDIR/Magisk_Module ]] && echo "$MODDIR/Magisk_Module目录遗失" && exit 1
tools_path="$MODDIR/tools"
. "$tools_path/bin.sh"
#开始安装Magisk模块
magisk_Module_path="/data/adb/modules/backup"
#备份资料夹路径
backup_path=/data/media/0/Android/backup_script
[[ ! -d ${magisk_Module_path%/*} ]] && echoRgb "没有安装Magisk或是装了Magisk Lite" "0" "0" && exit 2
if [[ ! -d $magisk_Module_path ]]; then
	echoRgb "不存在Magisk模块 正在创建"
	mkdir -p "$magisk_Module_path" && cp -r "$MODDIR/Magisk_Module" "$magisk_Module_path/recovery" && cp -r "$MODDIR/tools" "$magisk_Module_path/recovery" && cp -r "$magisk_Module_path/recovery/tools/Magisk_backup" "$magisk_Module_path/backup2.sh"
	mkdir -p "$magisk_Module_path/cron.d" && mkdir -p "$backup_path"
	tail -n +74 "$0" >"$magisk_Module_path/backup.sh"
	unset PATH
	sh "$magisk_Module_path/backup.sh" &
	unset PATH
	. $MODDIR/appname.sh
	echoRgb "请编辑$nametxt中需要自动备份的软件(不包含卡刷包备份)"
else
	. $magisk_Module_path/module.prop
	[[ $version != 8.8.9 ]] && echoRgb "更新模块"
	rm -rf "$magisk_Module_path"
	mkdir -p "$magisk_Module_path" && cp -r "$MODDIR/Magisk_Module" "$magisk_Module_path/recovery" && cp -r "$MODDIR/tools" "$magisk_Module_path/recovery" && cp -r "$magisk_Module_path/recovery/tools/Magisk_backup" "$magisk_Module_path/backup2.sh"
	mkdir -p "$magisk_Module_path/cron.d" && mkdir -p "$backup_path"
	tail -n +61 "$0" >"$magisk_Module_path/backup.sh"
	unset PATH
	sh "$magisk_Module_path/backup.sh" &
	unset PATH
	. $MODDIR/appname.sh
	echoRgb "请编辑$nametxt中需要自动备份的软件(不包含卡刷包备份)"
fi
echo 'id=backup
name=数据备份
version=8.8.9
versionCode=1
author=落叶凄凉(高雄佬) 
description=自动生成卡刷包并于间隔一小时监控第三方软件数量进行卡刷包生成服务，防止突然不能开机时丢失软件 生成的卡刷包必须进入recovery刷入进行备份 凌晨3点进行总体数据备份'>"$magisk_Module_path/module.prop"

echo '#!/system/bin/sh
#2020/10/10
wait_start=1
until [[ $(getprop sys.boot_completed) -eq 1 && $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) = false ]]; do
	sleep 1
	[[ $wait_start -ge 180 ]] && exit 1
	let wait_start++
done
MODDIR=${0%/*}
if [[ -e $(magisk --path)/.magisk/busybox/crond ]]; then
	alias crond="$(magisk --path)/.magisk/busybox/crond"
else
	echo "没有crond" && exit 2
fi
chmod -R 777 "$MODDIR"
crond -c "$MODDIR/cron.d"
if [[ $(pgrep -f "backup/cron.d" | grep -v grep | wc -l) -ge 1 ]]; then
	echo "$(date +%T) backup: backup cron.d启动成功">>/data/media/0/Android/backup_script/卡刷包生成资讯.txt
fi'>>"$magisk_Module_path/service.sh"
echo "0 */8 * * * $filepath/bash $magisk_Module_path/backup.sh
0 3 * * * $filepath/bash $magisk_Module_path/backup2.sh">"$magisk_Module_path/cron.d/root"
sh "$magisk_Module_path/service.sh"

echo '#是否备份外部数据 即比如原神的数据包(1备份0不备份)
Backup_obb_data=1

#压缩算法(可用lz4 zstd tar tar为仅打包 有什么好用的压缩算法请联系我
#lz4压缩最快，但是压缩率略差 zstd拥有良好的压缩率与速度 当然慢于lz4
Compression_method=zstd'>/data/media/0/Android/backup_script/backup_settings.conf
exit
#!/system/bin/sh
#2020/10/10
MODDIR=${0%/*}
tools_path="$MODDIR/recovery/tools"
. "$tools_path/bin.sh"
zip_out="/data/media/0/Android/backup_script"
system="
com.google.android.apps.messaging
com.digibites.accubattery
com.google.android.inputmethod.latin
com.android.chrome"
log() {
	echo "$(date '+%T') $1: $2" >>"$zip_out/卡刷包生成资讯.txt"
}
get_launcher() {
	if [[ $(getprop ro.build.version.sdk) -gt 27 ]]; then
		# 获取默认桌面
		launcher_app="$(pm resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN | grep '/' | cut -f1 -d '/')"
		for launcher_app in $launcher_app; do
			if [[ $launcher_app != "" && $launcher_app != "android" ]]; then
				if [[ $(pgrep -f "$launcher_app" | grep -v 'grep' | wc -l) -ge 1 ]]; then
					echo "$launcher_app"
				fi
			fi
		done
	fi
}
touch_backup() {
	appinfo -d " " -o pn -pn $system $(get_launcher) -3 | wc -l >$MODDIR/Quantity
	nametxt="$MODDIR/recovery/script/Apkname.txt"
	appinfo -d " " -o ands,pn -pn $system $(get_launcher) -3 2>/dev/null | sort | while read name; do
		apkpath="$(pm path "$(echo "$name" | awk '{print $2}')" | cut -f2 -d ':' | head -1)"
		[[ ! -e $nametxt ]] && echo "#不需要备份的应用请在开头注释# 比如#xxxxxxxx 酷安" >"$nametxt"
		if [[ $(cat "$nametxt" | sed -e '/^$/d' | grep -w "$name") = "" ]]; then
			echo "$name ${apkpath%/*}" >>"$nametxt"
		fi
	done
	if [[ -e $MODDIR/recovery/META-INF/com/google/android/update-binary ]]; then
		cd "$MODDIR/recovery"
		if [[ -e $nametxt ]]; then
			zip -r "recovery备份.zip" "META-INF" "tools" "script" -x "tools/lz4" -x "tools/toast" -x "tools/apk/*" -x "tools/zip" -x "tools/busybox_path" -x "tools/Magisk_backup" -x "tools/bash"
			[[ ! -d $zip_out ]] && mkdir -p "$zip_out"
			mv "$MODDIR/recovery/recovery备份.zip" "$zip_out" 
			echoRgb "输出:$zip_out"
		fi
	fi
}
[[ ! -f $MODDIR/Quantity ]] && touch_backup && log "backup" "首次生成备份卡刷包 输出:$zip_out"
apk_quantity="$(cat "$MODDIR/Quantity")"
if [[ $(appinfo -d " " -o pn -pn $system $(get_launcher) -3 | wc -l) != $apk_quantity ]]; then
	touch_backup && log "backup" "软件$apk_quantity>$(cat "$MODDIR/Quantity")发生变化 生成卡刷包 输出:$zip_out"
else
	log "backup" "软件数量无变化"
fi