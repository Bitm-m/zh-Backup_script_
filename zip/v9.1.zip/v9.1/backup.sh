#!/system/bin/sh
MODDIR="${0%/*}"
test "$(id -u)" -ne 0 && echo "你是憨批？不给Root用你妈 爬" && exit 1
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ $MODDIR = /data/media/0/Android/* ]] && echo "请勿在$MODDIR内备份" && exit 2
[[ ! -d $MODDIR/tools ]] && echo "$MODDIR/tools目录遗失" && exit 1
tools_path="$MODDIR/tools"
. "$tools_path/bin.sh"
. "$MODDIR/backup_settings.conf"
if [[ $(pgrep -f "$(basename "$0")" | grep -v grep | wc -l) -ge 2 ]]; then
	echoRgb "检测到进程残留，请重新执行脚本 已销毁进程" "0" "0"
	pgrep -f "$(basename "$0")" | grep -v grep | while read i; do
		kill -9 " $i" >/dev/null
	done
fi
isBoolean "$Lo" && Lo="$nsx"
if [[ $Lo = false ]]; then
	isBoolean "$Splist" && Splist="$nsx"
	isBoolean "$Backup_obb_data" && Backup_obb_data="$nsx"
	isBoolean "$path" && path3="$nsx"
else
	echoRgb "备份路径位置为绝对位置或是当前环境位置
 音量上当前环境位置，音量下脚本绝对位置"
	get_version "当前环境位置" "脚本绝对位置" && path3="$branch"
fi
i=1
path=/data/media/0/Android
path2=/data/user/0
if [[ $path3 = true ]]; then
	Backup="$PWD/Backup_$Compression_method"
	txt="$PWD/Apkname.txt"
else
	Backup="$MODDIR/Backup_$Compression_method"
	txt="$MODDIR/Apkname.txt"
fi
PU="$(ls /dev/block/vold | grep public 2>/dev/null)"
[[ ! -e $txt ]] && echoRgb "请执行appname.sh获取软件列表再来备份" "0" "0" && exit 1
r="$(cat "$txt" | grep -v "#" | sed -e '/^$/d' | sed -n '$=')"
[[ $r = "" ]] && echoRgb "爬..Apkname.txt是空的或是包名被注释了这样备份个鬼" "0" "0" && exit 1
data=/data
hx="本地"
if [[ $(pm path y.u.k) = "" ]]; then
	echoRgb "未安装toast 开始安装" "0" "0"
	if [[ $(getenforce) != Permissive ]]; then
		setenforce 0 2>/dev/null
		if [[ $? = 0 ]]; then
			echoRgb "selinux关闭成功" "0" "1" && pm install -r "$MODDIR/tools/apk"/*.apk >/dev/null 2>&1
		else
			echoRgb "selinux关闭失败 使用cp安装toast" "0" "0" &&  cp -r "$MODDIR/tools/apk"/*.apk /data/local/tmp && pm install -r /data/local/tmp/*.apk >/dev/null 2>&1 && rm -rf /data/local/tmp/*
		fi
	else
		pm install -r "$MODDIR/tools/apk"/*.apk >/dev/null 2>&1
	fi
	[[ $? = 0 ]] && echoRgb "安装toast成功" "0" "1" || echoRgb "安装toast失败" "0" "0"
fi
echoRgb "-压缩方式:$Compression_method"
echoRgb "-提示 脚本支持后台压缩 可以直接离开脚本
 -或是关闭终端也能备份 如需终止脚本
 -请再次执行$(basename "$0")即可停止
 -备份结束将发送toast提示语" "0" "2"
if [[ -d /proc/scsi/usb-storage || $PU != "" ]]; then
	PT="$(cat /proc/mounts | grep "$PU" | awk '{print $2}')"
	echoRgb "检测到usb 是否在usb备份
 音量上是，音量下不是"
	get_version "USB备份" "本地备份"
	if $branch = true ]]; then
		Backup="$PT/Backup_$Compression_method"
		data="/dev/block/vold/$PU"
		hx=USB
	fi
else
	echoRgb "没有检测到USB于本地备份"
fi
[[ ! -d $Backup ]] && mkdir "$Backup"
[[ ! -e $Backup/name.txt ]] && echo "#不需要恢复还原的应用请在开头注释# 比如#xxxxxxxx 酷安" >"$Backup/name.txt"
[[ ! -d $Backup/tools ]] && cp -r "$MODDIR/tools" "$Backup" && rm -rf "$Backup/tools"/restore* && rm -rf "$Backup/tools/apk" && rm -rf "$Backup/tools/toast" && rm -rf "$Backup/tools/Magisk_backup" && rm -rf "$Backup/tools/bash"
[[ ! -e $Backup/还原备份.sh ]] && cp -r "$MODDIR/tools/restore" "$Backup/还原备份.sh"
filesize="$(du -ks "$Backup" | awk '{print $1}')"
#调用二进制
Quantity=0
compression() {
	case $1 in
	obb|data)
		case $3 in
		tar|Tar|TAR) tar -cPpf - "$2" 2>/dev/null | pv -terb >"$Backup_folder/$1.tar" ;;
		zstd|Zstd|ZSTD) tar -cPpf - "$2" 2>/dev/null | pv -terb | zstd -r -T0 -6 -q >"$Backup_folder/$1.tar.zst" ;;
		lz4|Lz4|LZ4) tar -cPpf - "$2" 2>/dev/null | pv -terb | lz4 -1 >"$Backup_folder/$1.tar.lz4" ;;
		*) echoRgb "你个憨批$3是什么勾八" "0" "0" && rm -rf "$Backup" && exit 2
			;;
		esac ;;
	user)
		case $3 in
		tar|Tar|TAR) tar --exclude="$2/cache" --exclude="$2/lib" -cPpf - "$2" 2>/dev/null | pv -terb >"$Backup_folder/$1.tar" ;;
		zstd|Zstd|ZSTD) tar --exclude="$2/cache" --exclude="$2/lib" -cPpf - "$2" 2>/dev/null | pv -terb | zstd -r -T0 -6 -q >"$Backup_folder/$1.tar.zst" ;;
		lz4|Lz4|LZ4) tar --exclude="$2/cache" --exclude="$2/lib" -cPpf - "$2" 2>/dev/null | pv -terb | lz4 -1 >"$Backup_folder/$1.tar.lz4" ;;
		*) echoRgb "你个憨批$3是什么勾八" "0" "0" && rm -rf "$Backup" && exit 2
			;;
		esac ;;
	esac
}
#显示执行结果
echo_log() {
	if [[ $? = 0 ]]; then
		echoRgb "$1成功" "0" "1" && result=0
	else
		echoRgb "$1备份失败，过世了" "0" "0" && result=1
	fi
}
#检测apk状态进行备份
Backup_apk() {
	#创建APP备份文件夹
	[[ ! -d $Backup_folder ]] && mkdir "$Backup_folder"
	#备份apk
	apk_path="$(pm path "$name" | cut -f2 -d ':')"
	echoRgb "$1"
	[[ $(cat "$Backup/name.txt" | sed -e '/^$/d' | grep -w "$name" | head -1) = "" ]] && echo "$name2 $name" >>"$Backup/name.txt"
	if [[ $apk_version = $(pm dump "$name" | grep -m 1 versionName | sed -n 's/.*=//p') ]]; then
		unset xb
		echoRgb "Apk版本无更新 跳过备份"
	else
		rm -rf "$Backup_folder"/*.apk
		if [[ $apk_number = 1 ]]; then
			cp -r "$apk_path" "$Backup_folder/"
		else
			apk_path="$(pm path "$name" | cut -f2 -d ':' | head -1)"
			cp -r "${apk_path%/*}"/*.apk "$Backup_folder/"
		fi
		echo_log "备份$apk_number个Apk"
		if [[ $result = 0 ]]; then
			echo "apk_version=$(appinfo -o vc -pn "$name")" >>"$app_details"
			[[ $PackageName = "" ]] && echo "PackageName=$name">>"$app_details"
		fi
	fi
	if [[ $name = com.android.chrome ]]; then
		#删除所有旧apk ,保留一个最新apk进行备份
		ReservedNum=1
		FileNum="$(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null | wc -l)"
		while [[ $FileNum -gt $ReservedNum ]]; do
			OldFile="$(ls -rt /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null | head -1)"
			echoRgb "删除文件:${OldFile%/*/*}"
			rm -rf "${OldFile%/*/*}"
			let "FileNum--"
		done
		if [[ -e $(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null) && $(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null | wc -l) = 1 ]]; then
			cp -r "$(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null)" "$Backup_folder/nmsl.apk"
			echo_log "备份com.google.android.trichromelibrary"
		fi
	fi
	D=1
}
#检测数据位置进行备份
Backup_data() {
	if [[ $1 = user ]]; then
		data_path="$path2/$name"
	else
		data_path="$path/$1/$name"
	fi
	if [[ -d $data_path ]]; then
		case $1 in
			user) Size="$userSize" ;;
			data) Size="$dataSize" ;;
			obb) Size="$obbSize" ;;
		esac
		if [[ $Size = "" ]]; then
			nsxg=1
		else
			if [[ $Size != $(du -ks "$data_path" | awk '{print $1}') ]]; then
				nsxg=1
			else
				echoRgb "$1数据无发生变化 跳过备份"
				unset nsxg
			fi
		fi
		if [[ $nsxg != "" ]]; then
			compression "$1" "$data_path" "$Compression_method"
			echo_log "备份$1数据"
			[[ $result = 0 ]] && echo "$1Size=$(du -ks "$data_path" | awk '{print $1}')" >>"$app_details"
		fi
	else
		echoRgb "$1数据不存在跳过备份"
	fi
}

[[ $Lo = true ]] && {
echoRgb "选择是否只备份split apk(分割apk档)
 如果你不知道这意味什么请选择音量下进行混合备份
 音量上是，音量下不是"
get_version "是" "不是，混合备份" && Splist="$branch"
echoRgb "是否备份外部数据 即比如原神的数据包
 音量上备份，音量下不备份"
get_version "备份" "不备份" && Backup_obb_data="$branch"
}
bn=37
#开始循环$txt内的资料进行备份
#记录开始时间
starttime1="$(date -u "+%s")"
{
while [[ $i -le $r ]]; do
	echoRgb "备份第$i个应用 总共$r个 剩下$((r-i))个应用"
	name="$(cat "$txt" | grep -v "#" | sed -e '/^$/d' | sed -n "${i}p" | awk '{print $2}')"
	name2="$(cat "$txt" | grep -v "#" | sed -e '/^$/d' | sed -n "${i}p" | awk '{print $1}')"
	if [[ $name2 = *! || $name2 = *！ ]]; then
		name2=$(echo "$name2" | sed 's/!//g' | sed 's/！//g')
		echoRgb "跳过备份$name2 所有数据" "0" "0"
		No_backupdata=1
	else
		[[ $No_backupdata != "" ]] && unset No_backupdata
	fi
	Backup_folder="$Backup/$name2($name)"
	app_details="$Backup_folder/app_details"
	[[ -e $app_details ]] && . "$app_details"
	[[ $name = "" ]] && echoRgb "警告! name.txt软件包名获取失败，可能修改有问题" "0" "0" && exit 1
	if [[ $(pm path "$name") != "" ]]; then
		starttime2="$(date -u "+%s")"
		echoRgb "备份$name2 ($name)"
		[[ $name = com.tencent.mobileqq ]] && echo "QQ可能恢复备份失败或是丢失聊天记录，请自行用你信赖的软件备份"
		[[ $name = com.tencent.mm ]] && echo "WX可能恢复备份失败或是丢失聊天记录，请自行用你信赖的软件备份"
		apk_number="$(pm path "$name" | cut -f2 -d ':' | wc -l)"
		if [[ $apk_number = 1 ]]; then
			if [[ $Splist = false ]]; then
				[[ $name != $Open_apps ]] && am force-stop "$name"
				Backup_apk "非Split Apk"
			else
				echoRgb "非Split Apk跳过备份"
				unset D
			fi
		else
			[[ $name != $Open_apps ]] && am force-stop "$name"
			Backup_apk "Split Apk支持备份"
		fi
		if [[ $D != ""  && $result = 0 ]]; then
			[[ ! -e $Backup_folder/恢复$name2.sh ]] && cp -r "$MODDIR/tools/restore2" "$Backup_folder/恢复$name2.sh"
			[[ $name = bin.mt.plus && -e $Backup_folder/base.apk ]] && cp -r "$Backup_folder/base.apk" "$Backup_folder.apk"
			[[ $No_backupdata = "" ]] && {
			if [[ $Backup_obb_data = true ]]; then
				#备份data数据
				Backup_data "data"
				#备份obb数据
				Backup_data "obb"
			fi
			#备份user数据
			Backup_data "user"
			}
		fi
		endtime 2 "$name2备份"
		echoRgb "完成$((i*100/r))% $hx$(df -h "$data" | awk 'END{print "剩余:"$3"使用率:"$4}')"
	else
		echoRgb "$name2[$name]不在安装列表，备份个寂寞？" "0" "0"
	fi
	echo
	lxj="$(df -h "$data" | awk 'END{print $4}' | sed 's/%//g')"
	[[ $lxj -ge 95 ]] && echoRgb "$data空间不足,达到$lxj%" "0" "0" && exit 2
	let i++
done

echoRgb "你要备份跑路？祝你卡米9008" "0" "2"
#计算出备份大小跟差异性
filesizee="$(du -ks "$Backup" | awk '{print $1}')"
dsize="$(($((filesizee - filesize)) / 1024))"
echoRgb "备份资料夹路径:$Backup"
echoRgb "备份资料夹总体大小$(du -ksh "$Backup" | awk '{print $1}')"
if [[ $dsize -gt 0 ]]; then
	if [[ $((dsize / 1024)) -gt 0 ]]; then
		echoRgb "本次备份: $((dsize / 1024))gb"
	else
		echoRgb "本次备份: ${dsize}mb"
	fi
else
	echoRgb "本次备份: $(($((filesizee - filesize)) * 1000 / 1024))kb"
fi
echoRgb "批量备份完成"
[[ $(pm path y.u.k) != "" ]] && toast "批量备份完成"
endtime 1 "批量备份开始到结束"
exit 0
}&