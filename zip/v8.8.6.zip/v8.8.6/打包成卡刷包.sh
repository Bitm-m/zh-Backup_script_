MODDIR=${0%/*}
[[ -z $(echo "$MODDIR" | grep -v 'mt') ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $MODDIR/tools ]] && echo "$MODDIR/tools目录遗失" && exit 1
tools_path=$MODDIR/tools
. "$tools_path/bin.sh"
[[ ! -e $MODDIR/recovery.txt ]] && echoRgb "打包你妈呢？没有recovery.txt 请执行recovery备份包名生成.sh" "0" "0" && exit 1 || mv "$MODDIR/recovery.txt" "$MODDIR/recovery/script/Apkname.txt"
[[ ! -e $MODDIR/recovery/META-INF/com/google/android/update-binary ]] && echoRgb "update-binary不存在打包失败" "0" "0" && exit 1
[[ ! -d $MODDIR/recovery/tools ]] && echoRgb "$MODDIR/recovery/tools不存在打包失败" "0" "0" && exit 2
[[ -e $MODDIR/recovery备份.zip ]] && rm -rf "$MODDIR/recovery备份.zip"
cd "$MODDIR/recovery"
zip -r "recovery备份.zip" "META-INF" "tools" "script"
mv "$MODDIR/recovery/recovery备份.zip" "$MODDIR"
echoRgb "卡刷包路径:$MODDIR/recovery备份.zip"