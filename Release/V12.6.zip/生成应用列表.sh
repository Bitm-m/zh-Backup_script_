#!/system/bin/sh
MODDIR="${0%/*}"
#链接脚本设置环境变量
tools_path="$MODDIR/tools"
bin_path="$tools_path/bin"
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $tools_path ]] && echo " $tools_path目录遗失" && exit 1
[[ ! -f $MODDIR/backup_settings.conf ]] && echo "backup_settings.conf遗失" && exit 1
. "$bin_path/bin.sh"
. "$MODDIR/backup_settings.conf"
system="
com.google.android.apps.messaging
com.google.android.inputmethod.latin
com.android.chrome"
# 获取默认桌面
launcher_app="$(pm resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN | grep '/' | cut -f1 -d '/')"
for launcher_app in $launcher_app; do
	[[ $launcher_app != "android" ]] && [[ $(pgrep -f "$launcher_app" | grep -v 'grep' | wc -l) -ge 1 ]] && launcher_app="$launcher_app"
done
isBoolean "$path" && txtpath="$nsx"
[[ $txtpath = true ]] && txtpath="$PWD" || txtpath="$MODDIR"
nametxt="$txtpath/应用列表.txt"
[[ ! -e $nametxt ]] && echo '#不需要备份的应用请在开头注释# 比如#酷安 xxxxxxxx\n#不需要备份数据比如酷安! xxxxxxxx应用名后方加一个惊叹号即可 注意是应用名不是包名' >"$nametxt"
echo >>"$nametxt"
echoRgb "请勿关闭脚本，等待提示结束"
i=1
bn=118
rm -rf "$MODDIR/tmp"
starttime1="$(date -u "+%s")"
appinfo -sort-i -d " " -o ands,pn -pn $system $launcher_app -3 2>/dev/null | sed 's/\///g ; s/\://g ; s/(//g ; s/)//g ; s/\[//g ; s/\]//g ; s/\-//g ; s/!//g' | grep -v 'ice.message' | while read; do
	[[ $bn -ge 229 ]] && bn=118
	app_1=($REPLY $REPLY)
	if [[ $(cat "$nametxt" | grep -oE "${app_1[1]}$") = "" ]]; then
		case ${app_1[1]} in
		*oneplus*|*miui*|*xiaomi*|*oppo*|*flyme*|*meizu*|com.android.soundrecorder|com.mfashiongallery.emag|com.mi.health|*coloros*)
			echoRgb "$REPLY 可能是厂商自带应用 比对中....." "0"
			if [[ $(appinfo -sort-i -d " " -o ands,pn -xm | grep -w "$REPLY") = $REPLY ]]; then
				echoRgb "为Xposed模块 进行添加" "1"
				echo "$REPLY" >>"$nametxt" && xz=1 && [[ ! -e $MODDIR/tmp ]] && touch "$MODDIR/tmp"
				echoRgb "$i.$REPLY"
			else
				echoRgb "非Xposed模块 忽略输出" "0"
			fi
			;;
		*)
			echo "$REPLY" >>"$nametxt" && xz=1 && [[ ! -e $MODDIR/tmp ]] && touch "$MODDIR/tmp"
			echoRgb "$i.$REPLY"
			;;
		esac
	else
		unset xz
	fi
	[[ $xz != "" ]] && let i++ bn++
done
[[ -f $nametxt ]] && (cat "$nametxt" | sed -e '/^$/d' >"$nametxt.tmp" && mv "$nametxt.tmp" "$nametxt") || (echoRgb "$nametxt生成失败" "0" && exit 2)
endtime 1
[[ ! -e $MODDIR/tmp ]] && echoRgb "无新增应用" || echoRgb "输出包名结束 请查看$nametxt"
rm -rf "$MODDIR/tmp"