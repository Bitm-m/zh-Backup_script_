#!/system/bin/sh
MODDIR="${0%/*}"
test "$(id -u)" -ne 0 && echo "你是憨批？不给Root用你妈 爬" && exit 1
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $MODDIR/tools ]] && echo " $MODDIR/tools目录遗失" && exit 1
#链接脚本设置环境变量
md5path="$MODDIR"
tools_path="$MODDIR/tools"
. "$tools_path/bin.sh"
. "$MODDIR/backup_settings.conf"
system="
com.google.android.apps.messaging
com.digibites.accubattery
com.google.android.inputmethod.latin
com.android.chrome"
get_launcher() {
	if [[ $(getprop ro.build.version.sdk) -gt 27 ]]; then
		# 获取默认桌面
		launcher_app="$(pm resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN | grep '/' | cut -f1 -d '/')"
		for launcher_app in $launcher_app; do
			if [[ $launcher_app != "" && $launcher_app != "android" ]]; then
				if [[ $(pgrep -f "$launcher_app" | grep -v 'grep' | wc -l) -ge 1 ]]; then
					echo "$launcher_app"
				fi
			fi
		done
	fi
}
isBoolean "$path" && txtpath="$nsx"
[[ $txtpath = true ]] && txtpath="$PWD" || txtpath="$MODDIR"
[[ $backup_path != "" ]] && nametxt="$backup_path/Apkname.txt" || nametxt="$txtpath/Apkname.txt"
echoRgb " 请勿关闭脚本，等待提示结束"
i=1
bn=37
rm -rf "$MODDIR/tmp"
starttime1="$(date -u "+%s")"
appinfo -d " " -o ands,pn -pn $system $(get_launcher) -3 2>/dev/null | sort | while read name; do
	[[ $bn -ge 37 ]] && bn=31
	[[ ! -e $nametxt ]] && echo '#不需要备份的应用请在开头注释# 比如#酷安 com.coolapk.market
#不需要备份数据比如酷安! com.coolapk.market软件名后方加一个惊叹号即可 注意是软件名不是包名' >"$nametxt"
	if [[ $(cat "$nametxt" | sed -e '/^$/d' | sed 's/!//g' | sed 's/！//g' | grep -w "$name") = ""   ]]; then
		echo "$name" >>"$nametxt" && xz=1 && [[ ! -e $MODDIR/tmp ]] && touch "$MODDIR/tmp"
		echoRgb "$i.$name"
	else
		unset xz
	fi
	[[ $xz != "" ]] && let i++ bn++
done
endtime 1
[[ ! -e $MODDIR/tmp ]] && echoRgb "无新增应用" || echoRgb " 输出包名结束 请查看$nametxt"
rm -rf "$MODDIR/tmp"