MODDIR="${0%/*}"
#链接脚本设置环境变量
tools_path="$MODDIR/tools"
bin_path="$tools_path/bin"
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $tools_path ]] && echo " $tools_path目录遗失" && exit 1
. "$bin_path/bin.sh"
find "$MODDIR" -maxdepth 1 -name "*.zip" -type f -exec rm -rf {} \;
if [[ $backup_version != $(down -s -A s "https://api.github.com/repos/YAWAsau/backup_script/releases/latest" | jq -r '.tag_name') ]]; then
	down -s -A s "https://api.github.com/repos/YAWAsau/backup_script/releases/latest" | jq -r '.tag_name'>"$bin_path/tag" ; tag="$(cat "$bin_path/tag")"
	down -L -o "$MODDIR/$tag.zip" "$(down -s -A s "https://api.github.com/repos/YAWAsau/backup_script/releases/latest" | sed -r -n 's/.*"browser_download_url": *"(.*.zip)".*/\1/p')"
	echo_log "下载$tag.zip"
fi
if [[ $(find "$MODDIR" -maxdepth 1 -name "*.zip" -type f) = "" ]]; then
	echoRgb "警告 未找到任何zip 请将下载的备份脚本.zip\n -放入当前目录中\n -当前路径$MODDIR" "0"
else
	[[ $(find "$MODDIR" -maxdepth 1 -name "*.zip" -type f | wc -l) -gt 1 ]] && echoRgb "错误 请删除当前目录多余zip\n -保留一个最新的数据备份.zip\n -下列为当期目录zip\n$(find "$MODDIR" -maxdepth 1 -name "*.zip" -type f)" "0" && exit 1
fi
find "$MODDIR" -maxdepth 1 -name "*.zip" -type f | while read; do
	if [[ $(unzip -l "$REPLY" | awk '{print $4}' | grep -oE "^backup_settings.conf$") != "" ]]; then
		unzip -o "$REPLY" -d "$MODDIR" && (
		echoRgb "解压缩${REPLY##*/}成功" "1"
		case $MODDIR in
		*Backup_*)
			echoRgb "更新当前${MODDIR##*/}目录下恢复相关脚本+tools目录"
			cp -r "$tools_path/script/Get_DirName" "$MODDIR/扫描资料夹名.sh"
			cp -r "$tools_path/script/restore" "$MODDIR/还原备份.sh"
			[[ -d $MODDIR/媒体 ]] && cp -r "$tools_path/script/restore3" "$MODDIR/媒体/恢复多媒体数据.sh"
			find "$MODDIR" -maxdepth 1 -type d | sort | sed 's/\[/ /g ; s/\]//g' | while read; do
				if [[ -f $REPLY/app_details ]]; then
					unset PackageName
					. "$REPLY/app_details"
					if [[ $PackageName != "" ]]; then
						cp -r "$tools_path/script/restore2" "$REPLY/还原备份.sh"
					fi
				fi
			done
			rm -rf "$tools_path/script" "$tools_path/META-INF" "$tools_path/bin/zip" "$MODDIR/backup_settings.conf" "$MODDIR/备份应用.sh" "$MODDIR/生成应用列表.sh" ;;
		*)
			if [[ $(find "$MODDIR" -maxdepth 1 -name "Backup_*" -type d) != "" ]]; then
				find "$MODDIR" -maxdepth 1 -name "Backup_*" -type d | while read backup_path; do
					if [[ -d $backup_path && $backup_path != $MODDIR ]]; then
						echoRgb "更新当前目录下备份相关脚本&tools目录+${backup_path##*/}内tools目录+恢复脚本+tools"
						cp -r "$tools_path" "$backup_path" && rm -rf "$backup_path/tools/bin/zip" "$backup_path/tools/META-INF" "$backup_path/tools/script"
						cp -r "$tools_path/script/restore" "$backup_path/还原备份.sh"
						cp -r "$tools_path/script/Get_DirName" "$backup_path/扫描资料夹名.sh"
						cp -r "$MODDIR/本地一键更新脚本.sh" "$backup_path/本地一键更新脚本.sh"
						[[ -d $backup_path/媒体 ]] && cp -r "$tools_path/script/restore3" "$backup_path/媒体/恢复多媒体数据.sh"
						find "$MODDIR" -maxdepth 2 -type d | sort | sed 's/\[/ /g ; s/\]//g' | while read; do
							if [[ -f $REPLY/app_details ]]; then
								unset PackageName
								. "$REPLY/app_details"
								[[ $PackageName != "" ]] && cp -r "$tools_path/script/restore2" "$REPLY/还原备份.sh"
							fi
						done
					fi
				done
			else
				echoRgb "更新当前${MODDIR##*/}目录下备份相关脚本+tools目录"
			fi ;;
		esac) || (echoRgb "解压缩${REPLY##*/}失败" "0" && exit 2)
	else
		echoRgb "${REPLY##*/}并非指定的备份zip" "0"
	fi
done
find "$MODDIR" -maxdepth 1 -name "*.zip" -type f -exec rm -rf {} \;