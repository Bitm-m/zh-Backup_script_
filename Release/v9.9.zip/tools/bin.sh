test "$(whoami)" != root && echo "你是憨批？不给Root用你妈 爬" && exit 1
abi="$(getprop ro.product.cpu.abi)"
case $abi in
arm64*) 
	[[ $(getprop ro.build.version.sdk) -lt 28 ]] && echo "设备Android $(getprop ro.build.version.release)版本过低 请升级至Android 9+" && exit 1
	;;
*)
	echo "-未知的架构: $abi"
	exit 1
	;;
esac
export PATH="$(magisk --path)/.magisk/busybox:/system_ext/bin:/system/bin:/system/xbin:/vendor/bin:/vendor/xbin"
backup_version="V9.9 2021/10/8-20:59"
#设置二进制命令目录位置
[[ $tools_path = "" ]] && echo "未正确指定bin.sh位置" && exit 2
tools_path="${tools_path/'/storage/emulated/'/'/data/media/'}"
chmod -R 777 "$tools_path"
Status_log="${tools_path%/*}/执行状态日志.txt"
rm -rf "$Status_log"
filepath="/data/backup_tools"
busybox="$filepath/busybox"
#排除自身
exclude="
busybox_path
bin.sh"
rm_busyPATH() {
	if [[ ! -d $filepath ]]; then
		mkdir -p "$filepath"
		[[ $? = 0 ]] && echo "设置busybox环境中"
	fi
	[[ ! -f $tools_path/busybox_path ]] && touch "$tools_path/busybox_path"
	if [[ $filepath != $(cat "$tools_path/busybox_path") ]]; then
		[[ -d $(cat "$tools_path/busybox_path") ]] && rm -rf "$(cat "$tools_path/busybox_path")"
		echo "$filepath">"$tools_path/busybox_path"
	fi
}
rm_busyPATH
#删除无效软连结
find -L "$filepath" -maxdepth 1 -type l -exec rm -rf {} \;
if [[ -d $tools_path ]]; then
	[[ ! -f $tools_path/busybox ]] && echo "$tools_path/busybox不存在" && exit 1
	find "$tools_path" -maxdepth 1 -type f | egrep -v "$(echo $exclude | sed 's/ /\|/g')" | while read; do
		File_name="${REPLY##*/}"
		if [[ ! -f $filepath/$File_name ]]; then
			ln -fs "$REPLY" "$filepath"
			echo "$File_name > $filepath/$File_name"
		fi
		[[ ! -x $REPLY ]] && echo "$REPLY权限不可执行" && exit 1
	done
	rm_busyPATH
	"$busybox" --list | while read; do
		if [[ $REPLY != tar && ! -f $filepath/$REPLY ]]; then
			ln -fs "$busybox" "$filepath/$REPLY"
		fi
	done
else
	echo "遗失$tools_path"
	exit 1
fi
if [[ ! -f $busybox ]]; then
	echo "不存在$busybox ...."
	exit 1
fi
export PATH="$filepath:/system_ext/bin:/system/bin:/system/xbin:/vendor/bin:/vendor/xbin"
export TZ=Asia/Taipei
Open_apps="$(dumpsys window | grep -w mCurrentFocus | egrep -oh "[^ ]*/[^//}]+" | cut -f 1 -d "/")"

#下列为自定义函数
endtime() {
	#计算总体切换时长耗费
	case $1 in
	1) starttime="$starttime1" ;;
	2) starttime="$starttime2" ;;
	esac
	endtime="$(date -u "+%s")"
	duration="$(echo $((endtime - starttime)) | awk '{t=split("60 秒 60 分 24 时 999 天",a);for(n=1;n<t;n+=2){if($1==0)break;s=$1%a[n]a[n+1]s;$1=int($1/a[n])}print s}')"
	[[ $duration != "" ]] && echoRgb "$2用时:$duration" || echoRgb "$2用时:0秒"
}
echoRgb() {
	#转换echo颜色提高可读性
	if [[ $2 != "" ]]; then
		if [[ $3 = 0 ]]; then
			echo -e "\e[38;5;196m -$1\e[0m"
		elif [[ $3 = 1 ]]; then
			echo -e "\e[38;5;82m -$1\e[0m"
		elif [[ $3 = 2 ]]; then
			echo -e "\e[38;5;87m -$1\e[0m"
		else
			echo -e "\e[38;5;196m $1 $2 $3 颜色控制项错误\e[0m"; exit 2
		fi
	else
		echo -e "\e[38;5;${bn}m -$1\e[0m"
	fi
	echo " -$1">>"$Status_log"
}
get_version() {
	while :; do
		version="$(getevent -qlc 1 | awk '{ print $3 }')"
		case $version in
		KEY_VOLUMEUP)
			branch=true
			echoRgb "$1"
			;;
		KEY_VOLUMEDOWN)
			branch=false
			echoRgb "$2"
			;;
		*)
			continue
			;;
		esac
		sleep 1.2
		break
	done
}
isBoolean() {
	nsx="$1"
	if [[ $1 = 1 ]];then
		nsx=true
	elif [[ $1 = 0 ]];then
		nsx=false
	else
		echoRgb "$MODDIR/backup_settings.conf $1填写错误" "0" "0" && exit 2
	fi
}
bn=205
echoRgb "环境变数:$PATH\n -busybox版本:$(busybox | head -1 | awk '{print $2}')\n -appinfo版本:$(appinfo --version)\n -脚本版本:$backup_version\n -设备架构$abi\n -品牌:$(getprop ro.product.brand)\n -设备代号:$(getprop ro.product.device)\n -型号:$(getprop ro.product.model)\n -Android版本:$(getprop ro.build.version.release)\n -SDK:$(getprop ro.build.version.sdk)\n -终端:$(appinfo -o ands -pn "$Open_apps" 2>/dev/null)"
bn=195