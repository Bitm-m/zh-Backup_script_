SKIPUNZIP=0
REPLACE="
"
sh "$MODPATH/service.sh"
# 仅某些特殊文件需要特定权限
#默认权限在大多数情况下应该足够
set_perm_recursive "$MODPATH/system/bin" root root 0777 0777
