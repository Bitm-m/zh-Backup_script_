#!/system/bin/sh
#2020/10/10
MODDIR="${0%/*}"
tools_path="$MODDIR/recovery/tools"
. "$tools_path/bin.sh"
zip_out="/data/media/0/Android/backup_script"
if [[ ! -e $MODDIR/cron.d/root ]]; then
	echo "* */4 * * * $filepath/bash $MODDIR/backup.sh">"$MODDIR/cron.d/root"
fi
system="
com.google.android.apps.messaging
com.digibites.accubattery
com.google.android.inputmethod.latin
com.android.chrome"
log() {
	echo "$(date '+%T') $1: $2" >>"$zip_out/卡刷包生成资讯.txt"
}
get_launcher() {
	if [[ $(getprop ro.build.version.sdk) -gt 27 ]]; then
		# 获取默认桌面
		launcher_app="$(pm resolve-activity --brief -c android.intent.category.HOME -a android.intent.action.MAIN | grep '/' | cut -f1 -d '/')"
		for launcher_app in $launcher_app; do
			if [[ $launcher_app != "" && $launcher_app != "android" ]]; then
				if [[ $(pgrep -f "$launcher_app" | grep -v 'grep' | wc -l) -ge 1 ]]; then
					echo "$launcher_app"
				fi
			fi
		done
	fi
}
touch_backup() {
	appinfo -d " " -o pn -pn $system $(get_launcher) -3 | wc -l >$MODDIR/Quantity
	nametxt="$MODDIR/recovery/script/Apkname.txt"
	appinfo -d " " -o ands,pn -pn $system $(get_launcher) -3 2>/dev/null | sort | while read name; do
		apkpath="$(pm path "$(echo "$name" | awk '{print $2}')" | cut -f2 -d ':' | head -1)"
		[[ ! -e $nametxt ]] && echo "#不需要备份的应用请在开头注释# 比如#xxxxxxxx 酷安" >"$nametxt"
		if [[ $(cat "$nametxt" | sed -e '/^$/d' | grep -w "$name") = "" ]]; then
			echo "$name ${apkpath%/*}" >>"$nametxt"
		fi
	done
	if [[ -e $MODDIR/recovery/META-INF/com/google/android/update-binary ]]; then
		cd "$MODDIR/recovery"
		if [[ -e $nametxt ]]; then
			zip -r "recovery备份.zip" "META-INF" "tools" "script" -x "tools/lz4" -x "tools/zip" -x "tools/busybox_path" -x "tools/bash"
			[[ ! -d $zip_out ]] && mkdir -p "$zip_out"
			mv "$MODDIR/recovery/recovery备份.zip" "$zip_out" 
			echoRgb "输出:$zip_out"
		fi
	fi
}
[[ ! -f $MODDIR/Quantity ]] && touch_backup && log "backup" "首次生成备份卡刷包 输出:$zip_out"
apk_quantity="$(cat "$MODDIR/Quantity")"
if [[ $(appinfo -d " " -o pn -pn $system $(get_launcher) -3 | wc -l) != $apk_quantity ]]; then
	touch_backup && log "backup" "软件$apk_quantity>$(cat "$MODDIR/Quantity")发生变化 生成卡刷包 输出:$zip_out"
else
	log "backup" "软件数量无变化"
fi