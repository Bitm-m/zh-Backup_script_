#!/system/bin/sh
#2020/10/10
wait_start=1
until [[ $(getprop sys.boot_completed) -eq 1 && $(dumpsys window policy | grep "mInputRestricted" | cut -d= -f2) = false ]]; do
	sleep 1
	[[ $wait_start -ge 180 ]] && exit 1
	let wait_start++
done
MODDIR=${0%/*}
[[ ! -d /data/media/0/Android/backup_script ]] && mkdir -p /data/media/0/Android/backup_script
if [[ -e $(magisk --path)/.magisk/busybox/crond ]]; then
	alias crond="$(magisk --path)/.magisk/busybox/crond"
else
	echo "没有crond" && exit 2
fi
sh "$MODDIR/backup.sh"
chmod -R 777 "$MODDIR"
crond -c "$MODDIR/cron.d"
if [[ $(pgrep -f "backup/cron.d" | grep -v grep | wc -l) -ge 1 ]]; then
	echo "$(date +%T) backup: backup cron.d启动成功">>/data/media/0/Android/backup_script/卡刷包生成资讯.txt
fi
