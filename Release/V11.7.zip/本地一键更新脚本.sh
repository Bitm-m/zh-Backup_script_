MODDIR="${0%/*}"
#链接脚本设置环境变量
tools_path="$MODDIR/tools"
bin_path="$tools_path/bin"
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $tools_path ]] && echo " $tools_path目录遗失" && exit 1
. "$bin_path/bin.sh"
zippath="$(find "$MODDIR" -maxdepth 1 -name "*.zip" -type f)"
if [[ $zippath != "" ]]; then
	case $(echo "$zippath" | wc -l) in
	1)
		echoRgb "从$zippath更新" ;;
	*)
		echoRgb "错误 请删除当前目录多余zip\n -保留一个最新的数据备份.zip\n -下列为当前目录zip\n$(find "$MODDIR" -maxdepth 1 -name "*.zip" -type f)" "0" && exit 1 ;;
	esac
else
	echoRgb "从GitHub更新"
	down -s -A s "https://api.github.com/repos/YAWAsau/backup_script/releases/latest" | jq -r '.tag_name'>"$bin_path/tag" ; tag="$(cat "$bin_path/tag" 2>/dev/null)"
	if [[ $backup_version != $(down -s -A s "https://api.github.com/repos/YAWAsau/backup_script/releases/latest" | jq -r '.tag_name') ]]; then
		down -o "$MODDIR/$tag.zip" "https://gh.api.99988866.xyz/$(down -s -A s "https://api.github.com/repos/YAWAsau/backup_script/releases/latest" | sed -r -n 's/.*"browser_download_url": *"(.*.zip)".*/\1/p')"
		echo_log "下载$tag.zip"
		if [[ $result = 0 ]]; then
			zippath="$(find "$MODDIR" -maxdepth 1 -name "*.zip" -type f)"
		else
			echoRgb "请手动将备份脚本压缩包放置在\n -$MODDIR后再次执行脚本进行更新" "0" && exit 2
		fi
	else
		echoRgb "本地版本:$backup_version 线上版本:$tag 版本一致无须更新" && exit
	fi
fi
[[ $(unzip -l "$zippath" | awk '{print $4}' | grep -oE "^backup_settings.conf$") = "" ]] && echoRgb "${zippath##*/}并非指定的备份zip" "0" && exit 2
unzip -o "$zippath" -d "$MODDIR"
echo_log "解压缩${zippath##*/}"
if [[ $result = 0 ]]; then
	case $MODDIR in
	*Backup_*)
		echoRgb "更新当前${MODDIR##*/}目录下恢复相关脚本+tools目录"
		cp -r "$tools_path/script/Get_DirName" "$MODDIR/扫描资料夹名.sh"
		cp -r "$tools_path/script/restore" "$MODDIR/还原备份.sh"
		[[ -d $MODDIR/媒体 ]] && cp -r "$tools_path/script/restore3" "$MODDIR/媒体/恢复多媒体数据.sh"
		find "$MODDIR" -maxdepth 1 -type d | sort | while read; do
			if [[ -f $REPLY/app_details ]]; then
				unset PackageName
				. "$REPLY/app_details"
				[[ $PackageName != "" ]] && cp -r "$tools_path/script/restore2" "$REPLY/还原备份.sh"
			fi
		done
		rm -rf "$tools_path/script" "$tools_path/META-INF" "$tools_path/bin/zip" "$MODDIR/backup_settings.conf" "$MODDIR/备份应用.sh" "$MODDIR/生成应用列表.sh" ;;
	*)
		if [[ $(find "$MODDIR" -maxdepth 1 -name "Backup_*" -type d) != "" ]]; then
			find "$MODDIR" -maxdepth 1 -name "Backup_*" -type d | while read backup_path; do
				if [[ -d $backup_path && $backup_path != $MODDIR ]]; then
					echoRgb "更新当前目录下备份相关脚本&tools目录+${backup_path##*/}内tools目录+恢复脚本+tools"
					cp -r "$tools_path" "$backup_path" && rm -rf "$backup_path/tools/bin/zip" "$backup_path/tools/META-INF" "$backup_path/tools/script"
					cp -r "$tools_path/script/restore" "$backup_path/还原备份.sh"
					cp -r "$tools_path/script/Get_DirName" "$backup_path/扫描资料夹名.sh"
					cp -r "$MODDIR/本地一键更新脚本.sh" "$backup_path/本地一键更新脚本.sh"
					[[ -d $backup_path/媒体 ]] && cp -r "$tools_path/script/restore3" "$backup_path/媒体/恢复多媒体数据.sh"
					find "$MODDIR" -maxdepth 2 -type d | sort | while read; do
						if [[ -f $REPLY/app_details ]]; then
							unset PackageName
							. "$REPLY/app_details"
							[[ $PackageName != "" ]] && cp -r "$tools_path/script/restore2" "$REPLY/还原备份.sh"
						fi
					done
				fi
			done
		else
			echoRgb "更新当前${MODDIR##*/}目录下备份相关脚本+tools目录"
		fi ;;
	esac
fi
find "$MODDIR" -maxdepth 1 -name "*.zip" -type f -exec rm -rf {} \;