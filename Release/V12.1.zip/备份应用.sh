#!/system/bin/sh
MODDIR="${0%/*}"
tools_path="$MODDIR/tools"
bin_path="$tools_path/bin"
script_path="$tools_path/script"
script="${0##*/}"
[[ $(echo "$MODDIR" | grep -v 'mt') = "" ]] && echo "我他妈骨灰给你扬了撒了TM不解压缩？用毛线 憨批" && exit 1
[[ ! -d $tools_path ]] && echo "$tools_path目录遗失" && exit 1
[[ ! -d $script_path ]] && echo "$script_path目录遗失" && exit 1
[[ ! -d $tools_path/apk ]] && echo "$tools_path/apk目录遗失" && exit 1
. "$bin_path/bin.sh"
. "$MODDIR/backup_settings.conf"
case $MODDIR in
/storage/emulated/0/Android/*|/data/media/0/Android/*|/sdcard/Android/*) echoRgb "请勿在$MODDIR内备份" "0" && exit 2 ;;
esac
case $Compression_method in
zstd|Zstd|ZSTD|tar|Tar|TAR|lz4|Lz4|LZ4) ;;
*) echoRgb "$Compression_method为不支持的压缩算法" "0" &&  exit 2 ;;
esac
[[ ! -f $MODDIR/backup_settings.conf ]] && echoRgb "backup_settings.conf遗失" "0" && exit 1
#效验选填是否正确
isBoolean "$Lo" && Lo="$nsx"
if [[ $Lo = false ]]; then
	isBoolean "$Splist" && Splist="$nsx"
	isBoolean "$USBdefault" && USBdefault="$nsx"
	isBoolean "$Backup_obb_data" && Backup_obb_data="$nsx"
	isBoolean "$path" && path3="$nsx"
	isBoolean "$Backup_user_data" && Backup_user_data="$nsx"
	isBoolean "$backup_media" && backup_media="$nsx"
else
	echoRgb "备份路径位置为绝对位置或是当前环境位置\n 音量上当前环境位置，音量下脚本绝对位置"
	get_version "当前环境位置" "脚本绝对位置" && path3="$branch"
fi
i=1
#数据目录
path="/data/media/0/Android"
path2="/data/user/0"
if [[ $path3 = true ]]; then
	Backup="$PWD/Backup_$Compression_method"
	txt="$PWD/应用列表.txt"
else
	Backup="$MODDIR/Backup_$Compression_method"
	txt="$MODDIR/应用列表.txt"
fi
PU="$(ls /dev/block/vold | grep public)"
[[ ! -f $txt ]] && echoRgb "请执行\"生成应用列表.sh\"获取应用列表再来备份" "0" && exit 1
r="$(cat "$txt" | grep -v "#" | sed -e '/^$/d' | sed -n '$=')"
[[ $r = "" ]] && echoRgb "爬..应用列表.txt是空的或是包名被注释了这样备份个鬼" "0" && exit 1
data=/data
hx="本地"
echoRgb "压缩方式:$Compression_method"
echoRgb "提示 脚本支持后台压缩 可以直接离开脚本\n -或是关闭终端也能备份 如需终止脚本\n -请再次执行$script即可停止\n -备份结束将发送toast提示语" "2"
if [[ $PU != "" ]]; then
	[[ -f /proc/mounts ]] && PT="$(cat /proc/mounts | grep "$PU" | awk '{print $2}')"
	if [[ -d $PT ]]; then
		if [[ $(echo "$MODDIR" | grep -oE "^${PT}") != "" || $USBdefault = true ]]; then
			hx="USB"
		else
			echoRgb "检测到随身碟 是否在随身碟备份\n -音量上是，音量下不是"
			get_version "选择了随身碟备份" "选择了本地备份"
			[[ $branch = true ]] && hx="USB"
		fi
		if [[ $hx = USB ]]; then
			Backup="$PT/Backup_$Compression_method"
			data="/dev/block/vold/$PU"
			mountinfo="$(df -T "$data" | awk 'END{print $1}')"
			case $mountinfo in
			fuseblk|exfat|NTFS|ext4)
				echoRgb "于随身碟备份 档案系统:$mountinfo" "1"
				;;
			*)
				echoRgb "随身碟档案系统$mountinfo不支持超过单档4GB\n -请格式化为exfat" "0" ; exit 1 ;;
			esac
		fi
	fi
else
	echoRgb "没有检测到随身碟于本地备份" "1"
fi
[[ $Backup_user_data = false ]] && echoRgb "当前backup_settings.conf的\n -Backup_user_data为0将不备份user数据" "0"
[[ $Backup_obb_data = false ]] && echoRgb "当前backup_settings.conf的\n -Backup_obb_data为0将不备份外部数据" "0"
[[ ! -d $Backup ]] && mkdir -p "$Backup"
[[ ! -f $Backup/应用列表.txt ]] && echo "#不需要恢复还原的应用请在开头注释# 比如#xxxxxxxx 酷安" >"$Backup/应用列表.txt"
[[ ! -f $Backup/recover.conf ]] && cp -r "$script_path/recover.conf" "$Backup"
[[ ! -d $Backup/tools ]] && cp -r "$tools_path" "$Backup" && rm -rf "$Backup/tools/bin/zip" "$Backup/tools/script"
[[ ! -f $Backup/还原备份.sh ]] && cp -r "$script_path/restore" "$Backup/还原备份.sh"
[[ ! -f $Backup/扫描资料夹名.sh ]] && cp -r "$script_path/Get_DirName" "$Backup/扫描资料夹名.sh"
filesize="$(du -ks "$Backup" | awk '{print $1}')"
#调用二进制
Quantity=0
#检测apk状态进行备份
Backup_apk() {
	#创建APP备份文件夹
	[[ ! -d $Backup_folder ]] && mkdir -p "$Backup_folder"
	[[ $(cat "$Backup/应用列表.txt" | grep -v "#" | sed -e '/^$/d' | awk '{print $2}' | grep -w "^${name2}$" | head -1) = "" ]] && echo "${Backup_folder##*/} $name2" >>"$Backup/应用列表.txt"
	if [[ $apk_version = $(dumpsys package "$name2" | awk '/versionName=/{print $1}' | cut -f2 -d '=' | head -1) ]]; then
		unset xb ; result=0
		echoRgb "Apk版本无更新 跳过备份"
	else
		[[ $lxj -ge 95 ]] && echoRgb "$hx空间不足,达到$lxj%" "0" && exit 2
		rm -rf "$Backup_folder"/*.apk
		#备份apk
		echoRgb "$1"
		[[ $name1 != $Open_apps ]] && am force-stop "$name2"
		echo "$apk_path" | sed -e '/^$/d' | while read; do
			path="$REPLY"
			b_size="$(ls -l "$path" | awk '{print $5}')"
			k_size="$(awk 'BEGIN{printf "%.2f\n", "'$b_size'"/'1024'}')"
			m_size="$(awk 'BEGIN{printf "%.2f\n", "'$k_size'"/'1024'}')"
			echoRgb "${path##*/} ${m_size}MB(${k_size}KB)" "2"
		done
		(cd "$apk_path2"
		case $Compression_method in
		tar|TAR|Tar) tar -cf "$Backup_folder/apk.tar" *.apk ;;
		lz4|LZ4|Lz4) tar -cf - *.apk | lz4 -1 >"$Backup_folder/apk.tar.lz4" ;;
		zstd|Zstd|ZSTD) tar -cf - *apk | zstd -r -T0 --ultra -6 -q >"$Backup_folder/apk.tar.zst" ;;
		esac)
		echo_log "备份$apk_number个Apk"
		if [[ $result = 0 ]]; then
			echo "apk_version=\"$(dumpsys package "$name2" | awk '/versionName=/{print $1}' | cut -f2 -d '=' | head -1)\"" >>"$app_details"
			[[ $PackageName = "" ]] && echo "PackageName=\"$name2\"" >>"$app_details"
			[[ $ChineseName = "" ]] && echo "ChineseName=\"$name1\"" >>"$app_details"
			[[ ! -f $Backup_folder/还原备份.sh ]] && cp -r "$script_path/restore2" "$Backup_folder/还原备份.sh"
			[[ ! -f $Backup_folder/recover.conf ]] && cp -r "$script_path/recover.conf" "$Backup_folder"
		fi
		if [[ $name2 = com.android.chrome ]]; then
			#删除所有旧apk ,保留一个最新apk进行备份
			ReservedNum=1
			FileNum="$(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null | wc -l)"
			while [[ $FileNum -gt $ReservedNum ]]; do
				OldFile="$(ls -rt /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null | head -1)"
				rm -rf "${OldFile%/*/*}" && echoRgb "删除文件:${OldFile%/*/*}"
				let "FileNum--"
			done
			[[ -f $(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null) && $(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null | wc -l) = 1 ]] && cp -r "$(ls /data/app/*/com.google.android.trichromelibrary_*/base.apk 2>/dev/null)" "$Backup_folder/nmsl.apk"
		fi
	fi
	[[ $name2 = bin.mt.plus && ! -f $Backup/$name1.apk ]] && cp -r "$apk_path" "$Backup/$name1.apk"
	unset ChineseName PackageName ; D=1
}
#检测数据位置进行备份
Backup_data() {
	unset zsize
	case $1 in
	user) Size="$userSize" && data_path="$path2/$name2" ;;
	data) Size="$dataSize" && data_path="$path/$1/$name2" ;;
	obb) Size="$obbSize" && data_path="$path/$1/$name2" ;;
	*) [[ -f $app_details ]] && Size="$(cat "$app_details" | awk "/$1Size/"'{print $1}' | cut -f2 -d '=' | tail -n1 | sed 's/\"//g')" ; data_path="$2" ; Compression_method1="$Compression_method" ; Compression_method=tar ; zsize=1
	esac
	if [[ -d $data_path ]]; then
		if [[ $Size != $(du -ks "$data_path" | awk '{print $1}') ]]; then
			[[ $name1 != $Open_apps ]] && am force-stop "$name2"
			[[ $lxj -ge 95 ]] && echoRgb "$hx空间不足,达到$lxj%" "0" && exit 2
			echoRgb "备份$1数据" "2"
			case $1 in
			user)
				case $Compression_method in
				tar|Tar|TAR) tar --exclude="${data_path##*/}/.ota" --exclude="${data_path##*/}/cache" --exclude="${data_path##*/}/lib" -cpf - -C "${data_path%/*}" "${data_path##*/}" 2>/dev/null | pv >"$Backup_folder/$1.tar" ;;
				zstd|Zstd|ZSTD) tar --exclude="${data_path##*/}/.ota" --exclude="${data_path##*/}/cache" --exclude="${data_path##*/}/lib" -cpf - -C "${data_path%/*}" "${data_path##*/}" 2>/dev/null | pv | zstd -r -T0 --ultra -6 -q >"$Backup_folder/$1.tar.zst" ;;
				lz4|Lz4|LZ4) tar --exclude="${data_path##*/}/.ota" --exclude="${data_path##*/}/cache" --exclude="${data_path##*/}/lib" -cpf - -C "${data_path%/*}" "${data_path##*/}" 2>/dev/null | pv | lz4 -1 >"$Backup_folder/$1.tar.lz4" ;;
				esac ;;
			*)
				case $Compression_method in
				tar|Tar|TAR) tar --exclude="Backup_"* --exclude="${data_path##*/}/cache" -cPpf - "$data_path" 2>/dev/null | pv >"$Backup_folder/$1.tar" ;;
				zstd|Zstd|ZSTD) tar --exclude="Backup_"* --exclude="${data_path##*/}/cache" -cPpf - "$data_path" 2>/dev/null | pv | zstd -r -T0 --ultra -6 -q >"$Backup_folder/$1.tar.zst" ;;
				lz4|Lz4|LZ4) tar --exclude="Backup_"* --exclude="${data_path##*/}/cache" -cPpf - "$data_path" 2>/dev/null | pv | lz4 -1 >"$Backup_folder/$1.tar.lz4" ;;
				esac ; [[ $Compression_method1 != "" ]] && Compression_method="$Compression_method1" ; unset Compression_method1 ;;
			esac
			echo_log "备份$1数据"
			if [[ $result = 0 ]]; then
				if [[ $zsize != "" ]]; then
					echo "#$1Size=\"$(du -ks "$data_path" | awk '{print $1}')\"" >>"$app_details"
					[[ $2 != $(cat "$app_details" | awk "/$1path/"'{print $1}' | cut -f2 -d '=' | tail -n1 | sed 's/\"//g') ]] && echo "#$1path=\"$2\"" >>"$app_details"
				else
					echo "$1Size=\"$(du -ks "$data_path" | awk '{print $1}')\"" >>"$app_details"
				fi
			fi
		else
			echoRgb "$1数据无发生变化 跳过备份"
		fi
	else
		if [[ -f $data_path ]]; then
			echoRgb "$1是一个文件 不支持备份" "0"
		else
			echoRgb "$1数据不存在跳过备份"
		fi
	fi
}
[[ $Lo = true ]] && {
echoRgb "选择是否只备份split apk(分割apk档)\n 如果你不知道这意味什么请选择音量下进行混合备份\n 音量上是，音量下不是"
get_version "是" "不是，混合备份" && Splist="$branch"
echoRgb "是否备份外部数据 即比如原神的数据包\n 音量上备份，音量下不备份"
get_version "备份" "不备份" && Backup_obb_data="$branch"
echoRgb "是否备份使用者数据\n 音量上备份，音量下不备份"
get_version "备份" "不备份" && Backup_user_data="$branch"
echoRgb "全部应用备份结束后是否备份自定义目录\n 音量上备份，音量下不备份"
get_version "备份" "不备份" && backup_media="$branch"
}
#开始循环$txt内的资料进行备份
#记录开始时间
starttime1="$(date -u "+%s")"
TIME="$starttime1"
en=118
{
while [[ $i -le $r ]]; do
	[[ $en -ge 229 ]] && en=118
	name1="$(cat "$txt" | grep -v "#" | sed -e '/^$/d' | sed -n "${i}p" | awk '{print $1}')"
	name2="$(cat "$txt" | grep -v "#" | sed -e '/^$/d' | sed -n "${i}p" | awk '{print $2}')"
	[[ $name2 = "" ]] && echoRgb "警告! 应用列表.txt应用包名获取失败，可能修改有问题" "0" && exit 1
	apk_path="$(pm path "$name2" | cut -f2 -d ':')"
	apk_path2="$(echo "$apk_path" | head -1)" ; apk_path2="${apk_path2%/*}"
	if [[ -d $apk_path2 ]]; then
		echoRgb "备份第$i/$r个应用 剩下$((r-i))个"
		if [[ $name1 = *! || $name1 = *！ ]]; then
			name1="$(echo "$name1" | sed 's/!//g ; s/！//g')"
			echoRgb "跳过备份$name1 所有数据" "0"
			No_backupdata=1
		else
			[[ $No_backupdata != "" ]] && unset No_backupdata
		fi
		Backup_folder="$Backup/$name1"
		app_details="$Backup_folder/app_details"
		if [[ -f $app_details ]]; then
			. "$app_details"
			if [[ $PackageName != $name2 ]]; then
				unset userSize ChineseName PackageName apk_version
				Backup_folder="$Backup/${name1}[${name2}]"
				app_details="$Backup_folder/app_details"
				[[ -f $app_details ]] && . "$app_details"
			fi
		fi
		lxj="$(df -h "$data" | awk 'END{print $4}' | sed 's/%//g')"
		[[ $hx = USB && $PT = "" ]] && echoRgb "随身碟意外断开 请检查稳定性" "0" && exit 1
		starttime2="$(date -u "+%s")"
		echoRgb "备份$name1 ($name2)"
		[[ $name2 = com.tencent.mobileqq ]] && echo "QQ可能恢复备份失败或是丢失聊天记录，请自行用你信赖的应用备份"
		[[ $name2 = com.tencent.mm ]] && echo "WX可能恢复备份失败或是丢失聊天记录，请自行用你信赖的应用备份"
		apk_number="$(echo "$apk_path" | wc -l)"
		if [[ $apk_number = 1 ]]; then
			if [[ $Splist = false ]]; then
				Backup_apk "非Split Apk"
			else
				echoRgb "非Split Apk跳过备份" && unset D
			fi
		else
			Backup_apk "Split Apk支持备份"
		fi
		if [[ $D != ""  && $result = 0 && $No_backupdata = "" ]]; then
			if [[ $Backup_obb_data = true ]]; then
				#备份data数据
				Backup_data "data"
				#备份obb数据
				Backup_data "obb"
			fi
			#备份user数据
			[[ $Backup_user_data = true ]] && Backup_data "user"
			[[ $name2 = github.tornaco.android.thanos ]] && Backup_data "thanox" "$(find "/data/system" -name "thanos*" -maxdepth 1 -type d)"
		fi
		endtime 2 "$name1备份"
		echoRgb "完成$((i*100/r))% $hx$(df -h "$data" | awk 'END{print "剩余:"$3"使用率:"$4}')"
		echoRgb "____________________________________" "3"
	else
		echoRgb "$name1[$name2]不在安装列表，备份个寂寞？" "0"
	fi
	if [[ $i = $r ]]; then
		endtime 1 "应用备份"
		if [[ $backup_media = true ]]; then
			A=1
			B="$(echo "$Custom_path" | grep -v "#" | sed -e '/^$/d' | sed -n '$=')"
			if [[ $B != "" ]]; then
				echoRgb "备份结束，备份多媒体"
				starttime1="$(date -u "+%s")"
				Backup_folder="$Backup/媒体"
				[[ ! -d $Backup_folder ]] && mkdir -p "$Backup_folder"
				[[ ! -f $Backup_folder/恢复多媒体数据.sh ]] && cp -r "$script_path/restore3" "$Backup_folder/恢复多媒体数据.sh"
				app_details="$Backup_folder/app_details"
				[[ -f $app_details ]] && . "$app_details"
				echo "$Custom_path" | grep -v "#" | sed -e '/^$/d' | while read; do
					echoRgb "备份第$A/$B个资料夹 剩下$((B-A))个"
					starttime2="$(date -u "+%s")"
					Backup_data "${REPLY##*/}" "$REPLY"
					endtime 2 "${REPLY##*/}备份" && echoRgb "完成$((A*100/B))% $hx$(df -h "$data" | awk 'END{print "剩余:"$3"使用率:"$4}')" && echoRgb "____________________________________" "3" && let A++
				done
				endtime 1 "自定义备份"
			else
				echoRgb "自定义路径为空 无法备份" "0"
			fi
		fi
	fi
	let i++ en++ nskg++
done
echoRgb "你要备份跑路？祝你卡米9008" "2"
#计算出备份大小跟差异性
filesizee="$(du -ks "$Backup" | awk '{print $1}')"
dsize="$(($((filesizee - filesize)) / 1024))"
echoRgb "备份资料夹路径:$Backup" "2"
echoRgb "备份资料夹总体大小$(du -ksh "$Backup" | awk '{print $1}')"
if [[ $dsize -gt 0 ]]; then
	if [[ $((dsize / 1024)) -gt 0 ]]; then
		echoRgb "本次备份: $((dsize / 1024))gb"
	else
		echoRgb "本次备份: ${dsize}mb"
	fi
else
	echoRgb "本次备份: $(($((filesizee - filesize)) * 1000 / 1024))kb"
fi
echoRgb "批量备份完成"
starttime1="$TIME"
endtime 1 "批量备份开始到结束"
longToast "批量备份完成"
Print "批量备份完成 执行过程请查看$Status_log"
exit 0
}&